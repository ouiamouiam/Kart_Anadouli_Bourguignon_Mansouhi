package fr.enseeiht.superjumpingsumokart.application.items;

import android.widget.ImageButton;

import fr.enseeiht.superjumpingsumokart.R;
import fr.enseeiht.superjumpingsumokart.application.DroneController;
import fr.enseeiht.superjumpingsumokart.arpack.DetectionTask;
import fr.enseeiht.superjumpingsumokart.arpack.GUIGame;

public class Obstacle extends Item {

    private final static String NAME = "obstacle";
    private final static String ITEM_TAG = "Item.obstacle";
    private final GUIGame GUI_GAME;

    /**
     * Default constructor of the class {@link Item}.
     *
     *
     * @param gui_game
     */
    public Obstacle(GUIGame gui_game) {
        super(NAME);
        GUI_GAME = gui_game;
    }

    @Override
    public boolean useItem(DroneController droneController, DetectionTask.Symbol marker) {
        //Nothing to do
        return false;
    }

    @Override
    public void applyEffect(DroneController droneController) {

        droneController.spinningJump();

    }

    //pour l'instant notre obstacle à le même design qu'une bannane
    @Override
    public void assignResource(ImageButton ib) { ib.setImageResource(R.drawable.banana);}
}